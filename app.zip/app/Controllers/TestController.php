<?php

namespace App\Controllers;

use App\Controllers\BaseController;

class TestController extends BaseController
{
	public function create()
{
    // $model = new NewsModel();

}
}