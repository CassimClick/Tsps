<div class="whyUs">
    <div class="container">
        <h2 class="txt-center">Why Choose Us</h2>
        <div class="row">
            <div class="col-md-4">
                <div class="iconBox">
                    <i class="fas fa-users icon"></i>
                    <h4>Trainers</h4>
                </div>
            </div>
            <div class="col-md-4">
                <div class="iconBox">
                    <i class="fas fa-user-graduate icon"></i>
                    <h4>Academic Excellence</h4>
                </div>
            </div>
            <div class="col-md-4">
                <div class="iconBox">
                    <i class="fas fa-futbol icon"></i>
                    <h4>Sports & Recreation</h4>
                </div>
            </div>
        </div>
        <br>
        <div class="row">
            <div class="col-md-4">
                <div class="iconBox">
                    <i class="fas fa-home icon"></i>
                    <h4>Conductive Environment</h4>
                </div>
            </div>
            <div class="col-md-4">
                <div class="iconBox">
                    <i class="fas fa-first-aid icon"></i>
                    <h4>Medical Facility</h4>
                </div>
            </div>
            <div class="col-md-4">
                <div class="iconBox">
                    <i class="fas fa-hands icon"></i>
                    <h4>Freedom Of Worship</h4>
                </div>
            </div>
        </div>
    </div>
</div>