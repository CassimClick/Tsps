<div class=" wrapper gallery-isotope grid-4 gutter-small clearfix" data-lightbox="gallery">
    <div class="gallery-item" style="position: absolute; left: 0px; top: 209px;">
        <a href="https://images.pexels.com/photos/1126384/pexels-photo-1126384.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500"
            data-lightbox="gallery-item" title="Students"><img
                src="https://images.pexels.com/photos/1126384/pexels-photo-1126384.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500"
                alt=""></a>
    </div>
    <div class="gallery-item" style="position: absolute; left: 0px; top: 209px;">
        <a href="https://images.pexels.com/photos/1126384/pexels-photo-1126384.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500"
            data-lightbox="gallery-item" title="Students"><img
                src="https://images.pexels.com/photos/1126384/pexels-photo-1126384.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500"
                alt=""></a>
    </div>
    <div class="gallery-item" style="position: absolute; left: 0px; top: 209px;">
        <a href="https://images.pexels.com/photos/63330/geese-water-birds-waterfowl-63330.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500"
            data-lightbox="gallery-item" title="Students"><img
                src="https://images.pexels.com/photos/63330/geese-water-birds-waterfowl-63330.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500"
                alt=""></a>
    </div>
    <div class="gallery-item" style="position: absolute; left: 0px; top: 209px;">
        <a href="https://images.pexels.com/photos/37833/rainbow-lorikeet-parrots-australia-rainbow-37833.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500"
            data-lightbox="gallery-item" title="Students"><img
                src="https://images.pexels.com/photos/37833/rainbow-lorikeet-parrots-australia-rainbow-37833.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500"
                alt=""></a>
    </div>
    <div class="gallery-item" style="position: absolute; left: 0px; top: 209px;">
        <a href="https://images.pexels.com/photos/110812/pexels-photo-110812.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500"
            data-lightbox="gallery-item" title="Students"><img
                src="https://images.pexels.com/photos/110812/pexels-photo-110812.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500"
                alt=""></a>
    </div>

</div>