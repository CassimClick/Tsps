<section id="home" class="divider">
    <div class="owl-carousel-1col" data-nav="true" id="mySlider">
        <div class="item  image" data-bg-img="assets/images/slider/eventImg.jpg">
            <div class="overlay"></div>
            <div class="display-table">
                <div class="display-table-cell">
                    <div class="container pb-150 pt-150">
                        <div class="row">
                            <div class="col-md-7 col-md-offset-5 box-overlay">
                                <div class="pb-50 pt-30 p-50 outline-border bg-white-transparent">
                                    <!-- <h2 class="text-uppercase text-white font-titillium font-weight-600 mb-0">TSPS
                                    </h2>

                                    <p class="font-16 text-white">
                                        Lorem ipsum dolor sit amet consectetur, adipisicing elit. Numquam aliquid
                                        suscipit sed eum! Placeat beatae, culpa nemo a ipsam nam?
                                    </p> -->

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="item  image" data-bg-img="assets/images/graduation/gradStudents.jpg">
            <div class="overlay"></div>
            <div class="display-table">
                <div class="display-table-cell">
                    <div class="container pb-150 pt-150">
                        <div class="row">
                            <div class="col-md-7 col-md-offset-5 box-overlay">
                                <div class="pb-50 pt-30 p-50 outline-border bg-white-transparent">
                                    <!-- <h2 class="text-uppercase text-white font-titillium font-weight-600 mb-0">Graduation
                                    </h2>

                                    <p class="font-16 text-white">
                                        Lorem ipsum dolor sit amet consectetur, adipisicing elit. Numquam aliquid
                                        suscipit sed eum! Placeat beatae, culpa nemo a ipsam nam?
                                    </p> -->

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="item  image" data-bg-img="assets/images/sps/middleBlock.jpg">
            <div class="overlay"></div>
            <div class="display-table">
                <div class="display-table-cell">
                    <div class="container pb-150 pt-150">
                        <div class="row">
                            <div class="col-md-7 col-md-offset-5 box-overlay">
                                <div class="pb-50 pt-30 p-50 outline-border bg-white-transparent">
                                    <!-- <h2 class="text-uppercase text-white font-titillium font-weight-600 mb-0">Graduation
                                    </h2>

                                    <p class="font-16 text-white">
                                        Lorem ipsum dolor sit amet consectetur, adipisicing elit. Numquam aliquid
                                        suscipit sed eum! Placeat beatae, culpa nemo a ipsam nam?
                                    </p> -->

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="item  image" data-bg-img="assets/images/sps/primary.jpg">
            <div class="overlay"></div>
            <div class="display-table">
                <div class="display-table-cell">
                    <div class="container pb-150 pt-150">
                        <div class="row">
                            <div class="col-md-7 col-md-offset-5 box-overlay">
                                <div class="pb-50 pt-30 p-50 outline-border bg-white-transparent">
                                    <!-- <h2 class="text-uppercase text-white font-titillium font-weight-600 mb-0">Graduation
                                    </h2> -->

                                    <!-- <p class="font-16 text-white">
                                        Lorem ipsum dolor sit amet, consectetur adipisicing elit. Porro eos quidem modi
                                        unde accusamus non eligendi tempore.
                                    </p> -->

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="item  image" data-bg-img="assets/images/sps/front1.jpg">
            <div class="overlay"></div>
            <div class="display-table">
                <div class="display-table-cell">
                    <div class="container pb-150 pt-150">
                        <div class="row">
                            <div class="col-md-7 col-md-offset-5 box-overlay">
                                <div class="pb-50 pt-30 p-50 outline-border bg-white-transparent">
                                    <!-- <h2 class="text-uppercase text-white font-titillium font-weight-600 mb-0">Secondary
                                        School
                                    </h2> -->
                                    <!-- 
                                    <p class="font-16 text-white">
                                        Lorem ipsum dolor sit amet, consectetur adipisicing elit. Porro eos quidem modi
                                        unde accusamus non eligendi tempore.
                                    </p> -->

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="item  image" data-bg-img="assets/images/sps/kimbweta.jpg">
            <div class="overlay"></div>
            <div class="display-table">
                <div class="display-table-cell">
                    <div class="container pb-150 pt-150">
                        <div class="row">
                            <div class="col-md-7 col-md-offset-5 box-overlay">
                                <div class="pb-50 pt-30 p-50 outline-border bg-white-transparent">
                                    <!-- <h2 class="text-uppercase text-white font-titillium font-weight-600 mb-0">
                                        Outdoor Discussion Benches (Vimbweta
                                    </h2> -->

                                    <!-- <p class="font-16 text-white">
                                        Lorem ipsum dolor sit amet, consectetur adipisicing elit. Porro eos quidem modi
                                        unde accusamus non eligendi tempore.
                                    </p> -->

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="item  image" data-bg-img="assets/images/sps/basket.jpg">
            <div class="overlay"></div>
            <div class="display-table">
                <div class="display-table-cell">
                    <div class="container pb-150 pt-150">
                        <div class="row">
                            <div class="col-md-7 col-md-offset-5 box-overlay">
                                <div class="pb-50 pt-30 p-50 outline-border bg-white-transparent">
                                    <!-- <h2 class="text-uppercase text-white font-titillium font-weight-600 mb-0">
                                        Outdoor Discussion Benches (Vimbweta
                                    </h2> -->

                                    <!-- <p class="font-16 text-white">
                                        Lorem ipsum dolor sit amet, consectetur adipisicing elit. Porro eos quidem modi
                                        unde accusamus non eligendi tempore.
                                    </p> -->

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>


    </div>
</section>