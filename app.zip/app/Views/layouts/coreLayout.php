<?=$this->include('layouts/header') ?>

<!-- Start main-content -->
<div class="main-content">
    <!-- Section: home -->
    <section id="home">
        <?=$this->renderSection('content') ?>

    </section>
</div>
<?=$this->include('layouts/footer') ?>