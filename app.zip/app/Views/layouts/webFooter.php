<script src="<?=base_url()?>/css/tsps/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="<?=base_url()?>/css/tsps/vendor/jquery.easing/jquery.easing.min.js"></script>
<script src="<?=base_url()?>/css/tsps/vendor/php-email-form/validate.js"></script>
<script src="<?=base_url()?>/css/tsps/vendor/jquery-sticky/jquery.sticky.js"></script>
<script src="<?=base_url()?>/css/tsps/vendor/venobox/venobox.min.js"></script>
<script src="<?=base_url()?>/css/tsps/vendor/waypoints/jquery.waypoints.min.js"></script>
<script src="<?=base_url()?>/css/tsps/vendor/counterup/counterup.min.js"></script>
<script src="<?=base_url()?>/css/tsps/vendor/owl.carousel/owl.carousel.min.js"></script>
<script src="<?=base_url()?>/css/tsps/vendor/isotope-layout/isotope.pkgd.min.js"></script>
<script src="<?=base_url()?>/css/tsps/vendor/aos/aos.js"></script>

<!-- Template Main JS File -->
<script src="<?=base_url()?>/css/tsps/js/main.js"></script>