<?=$this->extend('layouts/webFrame') ?>
<?=$this->section('content') ?>

<?= $this->include('components/new/carousel.php');?>
<?= $this->include('components/new/levels.php');?>
<?= $this->include('components/new/whyUs.php');?>
<?= $this->include('components/new/aboutUs.php');?>

<?=$this->endSection() ?>